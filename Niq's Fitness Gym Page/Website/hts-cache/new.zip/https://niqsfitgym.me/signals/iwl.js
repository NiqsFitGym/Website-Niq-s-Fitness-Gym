<!doctype html><html lang="sr-me"><head>
    <meta charset="utf-8">
    
      <title>Error 404 | Page not found</title>
    
    
    <meta name="description" content="">
    
    
    <link rel="preload" href="//7528302.fs1.hubspotusercontent-na1.net/hubfs/7528302/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/source-serif-pro-600.woff2" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="//7528304.fs1.hubspotusercontent-na1.net/hubfs/7528304/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/source-serif-pro-600.woff" as="font" type="font/woff" crossorigin><link rel="preload" href="//7528315.fs1.hubspotusercontent-na1.net/hubfs/7528315/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-300.woff2" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="//7528311.fs1.hubspotusercontent-na1.net/hubfs/7528311/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-300.woff" as="font" type="font/woff" crossorigin><link rel="preload" href="//7528302.fs1.hubspotusercontent-na1.net/hubfs/7528302/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-regular.woff2" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="//7528311.fs1.hubspotusercontent-na1.net/hubfs/7528311/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-regular.woff" as="font" type="font/woff" crossorigin><link rel="preload" href="//7528302.fs1.hubspotusercontent-na1.net/hubfs/7528302/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-500.woff2" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="//7528309.fs1.hubspotusercontent-na1.net/hubfs/7528309/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-500.woff" as="font" type="font/woff" crossorigin><link rel="preload" href="//7528302.fs1.hubspotusercontent-na1.net/hubfs/7528302/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-700.woff2" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="//7528315.fs1.hubspotusercontent-na1.net/hubfs/7528315/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-700.woff" as="font" type="font/woff" crossorigin>

  <style>
      @font-face {
        font-family: 'Source Serif Pro';
        font-style: normal;
        font-weight: 600;
        font-display: swap;
        src:
          url('//7528302.fs1.hubspotusercontent-na1.net/hubfs/7528302/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/source-serif-pro-600.woff2') format('woff2'),
          url('//7528304.fs1.hubspotusercontent-na1.net/hubfs/7528304/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/source-serif-pro-600.woff') format('woff');
      }
      /* montserrat-regular - vietnamese_latin-ext_latin_cyrillic-ext_cyrillic */
      @font-face {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 300;
        font-display: swap;
        src:
          url('//7528315.fs1.hubspotusercontent-na1.net/hubfs/7528315/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-300.woff2') format('woff2'),
          url('//7528311.fs1.hubspotusercontent-na1.net/hubfs/7528311/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-300.woff') format('woff');
      }
    
      /* montserrat-regular - vietnamese_latin-ext_latin_cyrillic-ext_cyrillic */
      @font-face {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 400;
        font-display: swap;
        src:
          url('//7528302.fs1.hubspotusercontent-na1.net/hubfs/7528302/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-regular.woff2') format('woff2'),
          url('//7528311.fs1.hubspotusercontent-na1.net/hubfs/7528311/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-regular.woff') format('woff');
      }
    
      /* montserrat-500 - vietnamese_latin-ext_latin_cyrillic-ext_cyrillic */
      @font-face {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 500;
        font-display: swap;
        src:
          url('//7528302.fs1.hubspotusercontent-na1.net/hubfs/7528302/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-500.woff2') format('woff2'),
          url('//7528309.fs1.hubspotusercontent-na1.net/hubfs/7528309/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-500.woff') format('woff');
      }
    
      /* montserrat-700 - vietnamese_latin-ext_latin_cyrillic-ext_cyrillic */
      @font-face {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 700;
        font-display: swap;
        src:
          url('//7528302.fs1.hubspotusercontent-na1.net/hubfs/7528302/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-700.woff2') format('woff2'),
          url('//7528315.fs1.hubspotusercontent-na1.net/hubfs/7528315/raw_assets/public/mV0_d-CmsDefaultSystemPages_hubspot/CmsDefaultSystemPages/fonts/montserrat-700.woff') format('woff');
      }
    </style>
    
    
      
    
    
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <meta property="og:description" content="">
    <meta property="og:title" content="">
    <meta name="twitter:description" content="">
    <meta name="twitter:title" content="">

    

    
    <style>
a.cta_button{-moz-box-sizing:content-box !important;-webkit-box-sizing:content-box !important;box-sizing:content-box !important;vertical-align:middle}.hs-breadcrumb-menu{list-style-type:none;margin:0px 0px 0px 0px;padding:0px 0px 0px 0px}.hs-breadcrumb-menu-item{float:left;padding:10px 0px 10px 10px}.hs-breadcrumb-menu-divider:before{content:'›';padding-left:10px}.hs-featured-image-link{border:0}.hs-featured-image{float:right;margin:0 0 20px 20px;max-width:50%}@media (max-width: 568px){.hs-featured-image{float:none;margin:0;width:100%;max-width:100%}}.hs-screen-reader-text{clip:rect(1px, 1px, 1px, 1px);height:1px;overflow:hidden;position:absolute !important;width:1px}
</style>

<link rel="stylesheet" href="//cdn2.hubspot.net/hub/7052064/hub_generated/template_assets/1724169735804/hubspot/cmsdefaultsystempages/css/main.min.css">
<link rel="stylesheet" href="//cdn2.hubspot.net/hub/7052064/hub_generated/template_assets/1724169734397/hubspot/cmsdefaultsystempages/css/templates/error.min.css">
    

    
<!--  Added by GoogleAnalytics4 integration -->
<script>
var _hsp = window._hsp = window._hsp || [];
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}

var useGoogleConsentModeV2 = true;
var waitForUpdateMillis = 1000;


if (!window._hsGoogleConsentRunOnce) {
  window._hsGoogleConsentRunOnce = true;

  gtag('consent', 'default', {
    'ad_storage': 'denied',
    'analytics_storage': 'denied',
    'ad_user_data': 'denied',
    'ad_personalization': 'denied',
    'wait_for_update': waitForUpdateMillis
  });

  if (useGoogleConsentModeV2) {
    _hsp.push(['useGoogleConsentModeV2'])
  } else {
    _hsp.push(['addPrivacyConsentListener', function(consent){
      var hasAnalyticsConsent = consent && (consent.allowed || (consent.categories && consent.categories.analytics));
      var hasAdsConsent = consent && (consent.allowed || (consent.categories && consent.categories.advertisement));

      gtag('consent', 'update', {
        'ad_storage': hasAdsConsent ? 'granted' : 'denied',
        'analytics_storage': hasAnalyticsConsent ? 'granted' : 'denied',
        'ad_user_data': hasAdsConsent ? 'granted' : 'denied',
        'ad_personalization': hasAdsConsent ? 'granted' : 'denied'
      });
    }]);
  }
}

gtag('js', new Date());
gtag('set', 'developer_id.dZTQ1Zm', true);
gtag('config', 'G-TY1XJ5FF5Z');
</script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-TY1XJ5FF5Z"></script>

<!-- /Added by GoogleAnalytics4 integration -->

    <link rel="canonical" href="https://niqsfitgym.me/404">


<meta property="og:url" content="https://niqsfitgym.me/404">
<meta name="twitter:card" content="summary">
<meta http-equiv="content-language" content="sr-me">






  <meta name="generator" content="HubSpot"></head>
  <body>
    <div class="body-wrapper   hs-content-id-0 hs-site-page page ">
      <!-- Begin partial -->

  <header class="system-logo">
    
      <span class="system-logo__company-name">Niq's Fitness Gym</span>
    
  </header>

<!-- End partial -->
      <main class="body-container-wrapper ">
        
  <section class="section-wrapper section-wrapper--narrow section-wrapper--centered">
    <div class="error-code">404</div>

    <div id="hs_cos_wrapper_error_heading" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module widget-type-rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module"><span id="hs_cos_wrapper_error_heading_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="rich_text"><h1>Page not found</h1></span></div>

    <div id="hs_cos_wrapper_error_description" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module widget-type-rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module"><span id="hs_cos_wrapper_error_description_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="rich_text"><p>We can't find the page you were looking for.</p></span></div>

    <div id="hs_cos_wrapper_return_button" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module button-wrapper" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module">
  



  
    
  



<a class="hs-button " href="/?hsLang=sr-me" id="hs-button_return_button" rel="">
  Go to home page
</a>

</div>
  </section>

      </main>
    </div>
    
    
    
    
<!-- HubSpot performance collection script -->
<script defer src="https://static.hsappstatic.net/content-cwv-embed/static-1.971/embed.js"></script>
<script>
var hsVars = hsVars || {}; hsVars['language'] = 'sr-me';
</script>

<script src="/hs/hsstatic/cos-i18n/static-1.53/bundles/project.js"></script>

<!-- Start of HubSpot Analytics Code -->
<script type="text/javascript">
var _hsq = _hsq || [];
_hsq.push(["setContentType", "standard-page"]);
_hsq.push(["setCanonicalUrl", "https:\/\/niqsfitgym.me\/404"]);
_hsq.push(["setPageId", ""]);
_hsq.push(["setContentMetadata", {
    "contentPageId": null,
    "legacyPageId": null,
    "contentFolderId": null,
    "contentGroupId": null,
    "abTestId": null,
    "languageVariantId": null,
    "languageCode": "sr-me",
    
    
}]);
</script>

<script type="text/javascript" id="hs-script-loader" async defer src="/hs/scriptloader/46178952.js?businessUnitId=0"></script>
<!-- End of HubSpot Analytics Code -->


<script type="text/javascript">
var hsVars = {
    render_id: "1e06a5e7-e8b4-4ea2-abd9-8b768e917113",
    ticks: 1724172985117,
    page_id: 0,
    
    content_group_id: 0,
    portal_id: 46178952,
    app_hs_base_url: "https://app.hubspot.com",
    cp_hs_base_url: "https://cp.hubspot.com",
    language: "sr-me",
    analytics_page_type: "standard-page",
    scp_content_type: "",
    analytics_page_id: "null",
    category_id: 1,
    folder_id: 0,
    is_hubspot_user: false
}
</script>


<script defer src="/hs/hsstatic/HubspotToolsMenu/static-1.349/js/index.js"></script>




  
</body></html>